fetch("data/sample.json").then(r => r.json()).then(d => { out.textContent = d.name; });
